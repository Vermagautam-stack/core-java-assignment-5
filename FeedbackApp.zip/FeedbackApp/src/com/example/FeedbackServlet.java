package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Handles feedback form submission (POST) and displays it back as HTML.
 * Mapped to /submitFeedback in web.xml.
 */
public class FeedbackServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // Read input parameters
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String type = request.getParameter("type");
        String comments = request.getParameter("comments");

        String dateTime = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date());

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html><head><meta charset=\"UTF-8\"><title>Thank You</title>");
        out.println("<style>body{font-family:Arial,sans-serif;background:#f4f6f8;}"
                + ".box{width:480px;margin:40px auto;padding:20px 25px;background:#fff;"
                + "border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.15);}"
                + "h2{color:#2c3e70;}</style></head><body>");
        out.println("<div class=\"box\">");
        out.println("<h2>Thank you, " + escape(name) + " for your feedback!</h2>");
        out.println("<p><b>Email:</b> " + escape(email) + "</p>");
        out.println("<p><b>Feedback Type:</b> " + escape(type) + "</p>");
        out.println("<p><b>Comments:</b> " + escape(comments) + "</p>");
        out.println("<p><b>Date &amp; Time:</b> " + dateTime + "</p>");
        out.println("<a href=\"feedback.html\">Submit another feedback</a>");
        out.println("</div></body></html>");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Direct visits to /submitFeedback go back to the form
        response.sendRedirect("feedback.html");
    }

    /** Escapes HTML special characters to prevent XSS. */
    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
