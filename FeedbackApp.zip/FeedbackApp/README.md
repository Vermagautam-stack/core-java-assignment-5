# FeedbackApp

Java Servlet web application (CSIT751 – Module V practical assignment).
A user submits feedback via an HTML form (POST); `FeedbackServlet` displays it back with the current date and time.

## Structure
```
FeedbackApp/
├── web/
│   ├── feedback.html
│   └── WEB-INF/web.xml
└── src/com/example/FeedbackServlet.java
```

## Run (Eclipse/IntelliJ + Tomcat 9)
1. Create a Dynamic Web Project named `FeedbackApp` and copy the files in.
2. Add Tomcat 9 to the build path (uses `javax.servlet`).
3. Run on server and open `http://localhost:8080/FeedbackApp/feedback.html`.

> Using Tomcat 10+? Replace `javax.servlet` with `jakarta.servlet` in the servlet imports.
